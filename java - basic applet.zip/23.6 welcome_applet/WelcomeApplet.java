/* Assignment: Assignment #2, CS 2550
	Date:		1/29/11
	Author:		Clayton Thomas
	Description: A very basic Java applet that print some text on a gray background.
*/

import java.awt.Graphics;
import javax.swing.JApplet;

public class WelcomeApplet extends JApplet {

   // draw text on applet's background
   public void paint(Graphics g) {
      
		// call superclass version of paint()
      super.paint(g);

      // draw a String at coordinate (25, 25)
      g.drawString("Welcome to Java Applets!", 25, 25);
   
	}
	
}
